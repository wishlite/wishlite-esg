---
name: wishlite-brand-guide
description: >
  韻手作 Wishlite 品牌設計規範與 Landing Page UX 原則。當使用者提到「修改頁面文案」、「調整排版」、「設計風格」、「品牌語氣」、「Landing Page 優化」、「轉換率」、「CTA」、「區塊設計」、「背景色」、「字體」、「配色」、「文案語氣」、「B2B 轉換」、「頁面太長」、「太多按鈕」或任何與韻手作網頁設計、文案撰寫、UX 調整相關的操作時，請使用此 Skill。即使只是改一句文案，也請先讀取此 Skill 以確保風格一致。
---

# Wishlite 韻手作 — 品牌設計規範與 Landing Page UX 原則

## 品牌語氣（Brand Voice）

核心：**溫柔、有畫面、先感受後理解**。

### 該做的
- 像溫暖的朋友在說話，不是企業在推銷
- 用畫面感帶入，短句優先，留白給讀者呼吸
- 讓讀者先「感受到」再「理解」

### 不該做的
- 不要像教科書（避免過度解釋）
- 不要推銷感語氣、不要堆砌術語
- 不要長段落說明

### 文案範例
- 好：「每一場活動的材料，都來自真實的循環故事。」
- 壞：「我們使用六種經過嚴格篩選的在地循環再生材料，包含咖啡渣、牡蠣殼…」（太長太教科書）

## Landing Page 設計原則

**頁面定位**：B2B 企業 ESG 活動轉換頁面，目標是填寫需求表單。所有設計決策回到：「這個區塊是否幫助企業更快做出填表決定？」

### CTA 策略
**核心：CTA 不要太多，看起來會煩。** 整頁最多 3 個 #form CTA：Nav 導航列、Hero、CTA Banner。不要在每個 Section 底部都加。

CTA 文案帶「報價」或「提案」等結果導向字眼，避免「了解更多」。

### 區塊背景色交替
- `var(--white)` — 白色
- `var(--soft)` #f9f6f0 — 米色
- `var(--cream)` #f5f0e8 — 杏色（少量）
- `var(--moss)` #3d5a3e — 深綠（重要區塊）

深色背景文字：標題 `#fff`、副標 `rgba(255,255,255,0.6)`、Label `var(--gold-light)`

### 轉換導向 vs 品牌教育
- 要：材料信任標籤（一行 tag）、數據、照片+一句結果導向文案
- 避免：每個材料展開故事、長篇品牌說明、在頁面內展開完整課程

### 內容長度
- 標題最多 20 字、副標最多 40 字
- 卡片最多 3 個 bullet，每個不超過 20 字

## 色彩系統

```
主色綠 moss #3d5a3e | 深綠 moss-dark #2e4630 | 淺綠 sage #7a9e7e
杏色 cream #f5f0e8 | 沙色 sand #e8dcc8 | 米色 soft #f9f6f0
金色 gold #c49a3c | 淺金 gold-light #d4b06a | 薄荷 mist #d4e4d0
墨色 ink #1e2a1e | 白色 white #ffffff
```

## 字體
- 標題：Noto Serif TC（襯線）
- 內文：Noto Sans TC（無襯線）
- 英文 Label：letter-spacing 2-2.5px, uppercase

## 按鈕樣式
- 主要（膠囊）：moss 背景、白字、border-radius 28px
- 次要（邊框）：白底、moss 字、1.5px moss 邊框
- 文字連結：moss 色、底線 1.5px
