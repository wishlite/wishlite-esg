---
name: wishlite-project-context
description: >
  韻手作 Wishlite 專案架構與部署背景。當使用者提到「wishlite」、「韻手作」、「ESG landing page」、「永續禮品頁面」、「index.html」、「wishlite-landing.html」、「wishlite-deploy-preview」、「GitHub Pages 部署」、「n8n webhook」、「修改網站」、「更新頁面」、「推送到 GitHub」或任何與韻手作網站開發、Landing Page 修改相關的操作時，請使用此 Skill。即使只是問一個頁面怎麼改，也請先讀取此 Skill。
---

# Wishlite 韻手作 — 專案架構與部署指南

本文件是韻手作所有 Landing Page 開發工作的背景參考。開始任何修改前，請先閱讀此文件。

## 部署架構

- **GitHub Repo**：`wishlite/wishlite-esg`
- **部署方式**：GitHub Pages（main branch 自動部署）
- **線上網址**：`https://wishlite.github.io/wishlite-esg/`
- **本地工作目錄**：`~/wishlite-deploy-preview/`（即 Cowork 掛載資料夾）

### 推送流程

所有 git push 必須在 **Mac Terminal** 執行，VM 無法直接 push（會遇到 proxy 403）。標準推送指令：

```bash
cd ~/wishlite-deploy-preview && git add -A && git commit -m "描述修改內容" && git push
```

## 檔案結構

```
~/wishlite-deploy-preview/
├── index.html                    ← ESG 活動 Landing Page（主頁）
├── wishlite-landing.html         ← 永續禮品 Landing Page
├── ESG 活動詢問獨立頁.html       ← ESG 表單獨立頁
├── 永續禮品詢問獨立頁.html       ← 禮品表單獨立頁
├── activity-kenvue.jpg           ← Solution 卡片1：ESG 活動體驗
├── gift-mountain.jpg             ← Solution 卡片2：永續禮品
├── report-esg.jpg                ← Solution 卡片3：ESG 成果報告
├── course-coffee-soap.jpg        ← 熱門課程：咖啡手工皂
├── course-mosaic-coaster2.jpg    ← 熱門課程：塑木馬賽克杯墊
├── course-seed-earth3.jpg        ← 熱門課程：種子地球
├── mat-coffee/fiber/oyster/plastic/textile/natural.jpg ← 六大材料圖
├── 格子1 - 我要辦活動.jpg        ← Hero 背景圖
├── 扁平畫1~4.jpg                 ← 合作場景插圖
├── ＥＳＧ合作案例2.jpg            ← Client Logos 區塊
├── ＥＳＧ合作案例3.jpg            ← Use Cases 區塊
└── hero-bg.png
```

## index.html Section 結構

| # | Section | 背景色 | CSS Class / ID |
|---|---------|--------|----------------|
| 1 | Hero | 深綠 moss-dark + 背景圖 | `.hero` |
| 2 | Trust Bar | 白色 | `.trust-bar` |
| 3 | Solution 三大服務卡片 | 米色 soft | `#solution .services` |
| 4 | Client Logos | 白色 | `.clients` |
| 5 | 服務對象 | 杏色 cream | `.services` |
| 6 | 熱門體驗方案 + CTA | 白色 | `.courses` |
| 7 | 材料信任標籤 | 米色 soft | `.mat-trust-section` |
| 8 | 合作場景 Use Cases | 米色 soft | `.pricing` |
| 9 | Why Us（HOW + WHY） | 深綠 moss | `.why-us` |
| 10 | Process 合作流程 | 白色 | `.process` |
| 11 | CTA Banner → 表單 Modal | 深綠 moss | `.cta-banner` `#form` |
| 12 | FAQ（2欄×6題） | 米色 soft | `.faq` |
| 13 | Footer | 深綠 moss-dark | `.footer` |

## 外部連結（Notion）

| 卡片 | 連結 |
|------|------|
| ESG 活動方案 | `https://wishlite.notion.site/esgdiy?v=2b2704274681819ea59c000cfd04a44c` |
| 永續禮品系列 | `https://wishlite.notion.site/esg-gifts?v=e6cf547cac9348b983de68ce3664f641` |
| ESG 合作案例 | `https://www.notion.so/wishlite/ESG-2c5704274681800d8b90f045e1f6cf00?source=copy_link` |
| 材料故事 | `https://www.notion.so/wishlite/2b270427468180028f19d35c4ed8f172?v=2b270427468180ab9257000c77235b97&source=copy_link` |

## CSS 色彩變數

```css
--moss: #3d5a3e; --moss-dark: #2e4630; --sage: #7a9e7e;
--cream: #f5f0e8; --sand: #e8dcc8; --soft: #f9f6f0;
--gold: #c49a3c; --gold-light: #d4b06a; --mist: #d4e4d0;
--ink: #1e2a1e; --white: #ffffff;
```

## 注意事項

- **VM 同步延遲**：新增圖片後 VM 可能看不到，Mac 端 `git status` 才準確
- **Git Push 限制**：VM 無法 push（403），必須在 Mac Terminal 執行
- **瀏覽器快取**：更新後需 Cmd+Shift+R 或開無痕視窗
- **Git Lock**：遇到 lock file 在 Mac Terminal 用 `rm .git/*.lock` 解決
