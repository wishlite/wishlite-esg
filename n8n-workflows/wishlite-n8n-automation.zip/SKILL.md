---
name: wishlite-n8n-automation
description: >
  韻手作 Wishlite n8n 自動化工作流架構與設定。當使用者提到「n8n」、「webhook」、「自動化」、「表單提交」、「通知流程」、「Zeabur」、「工作流」、「workflow」、「ESG 表單」、「禮品表單」、「API」、「自動回覆」、「email 通知」或任何與韻手作表單自動化、n8n 流程設定相關的操作時，請使用此 Skill。
---

# Wishlite 韻手作 — n8n 自動化工作流指南

## 部署環境

| 項目 | 值 |
|------|-----|
| 平台 | n8n（Self-hosted on Zeabur） |
| 網址 | `https://wishlite-n8n.zeabur.app` |
| 帳號 | wishlite1111@gmail.com |

注意：Zeabur 免費方案有休眠機制，長時間沒請求會休眠，第一次請求需幾秒喚醒。

## API 認證

```
API Key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4ZTgzMDUzOS0xYmM1LTQxYTYtODE5My04YmYxMzE3NjcxOTgiLCJpc3MiOiJuOG4iLCJhdWQiOiJwdWJsaWMtYXBpIiwianRpIjoiZmE1NzdmM2QtYTg2My00M2NiLTk2NTUtNDg5MmYwYmQ0Y2MyIiwiaWF0IjoxNzc0NzEyMjAxLCJleHAiOjE3NzcyMTkyMDB9.mKy5TIVdWCbGvsO8K3PopWh_tBJdJiehhqVPssz0Ijc
```

## 工作流程

### WF-1A：ESG 活動詢問

| 項目 | 值 |
|------|-----|
| Workflow ID | `G0u10QJ40ZLLgrt7` |
| Webhook URL | `https://wishlite-n8n.zeabur.app/webhook/esg-inquiry` |
| 觸發來源 | `index.html` 表單 Modal（#form） |

表單欄位：company, name, email, phone, people, type, time, budget, note

### WF-2A：永續禮品詢問

| 項目 | 值 |
|------|-----|
| Workflow ID | `wAexkU1zfLMJRvBL` |
| Webhook URL | `https://wishlite-n8n.zeabur.app/webhook/gift-inquiry` |
| 觸發來源 | `wishlite-landing.html` 表單 |

## 注意事項

- 不要更改 Webhook 路徑（`/webhook/esg-inquiry` 和 `/webhook/gift-inquiry`），前端 HTML 依賴這些路徑
- 新增欄位時前端 HTML 和 n8n webhook 都要同步更新
- 修改完工作流記得在 n8n 中 Activate

## 測試 Webhook

```bash
curl -X POST https://wishlite-n8n.zeabur.app/webhook/esg-inquiry \
  -H "Content-Type: application/json" \
  -d '{"company":"測試公司","name":"測試","email":"test@test.com","phone":"0912345678","people":"50","type":"ESG工作坊","time":"2026-04","budget":"5-10萬","note":"測試"}'
```
